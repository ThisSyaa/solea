import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'login_page.dart';
import 'profile_page.dart';

/// Data sederhana untuk satu baris di ListView.builder.
class _DashboardItem {
  final IconData icon;
  final String title;
  final String subtitle;
  const _DashboardItem(this.icon, this.title, this.subtitle);
}

const List<_DashboardItem> _dashboardItems = [
  _DashboardItem(Icons.dashboard_outlined, 'Dashboard', 'Ringkasan aktivitas kamu hari ini'),
  _DashboardItem(Icons.notifications_outlined, 'Notifikasi', '3 notifikasi belum dibaca'),
  _DashboardItem(Icons.task_alt_outlined, 'Tugas', '5 tugas menunggu diselesaikan'),
  _DashboardItem(Icons.calendar_today_outlined, 'Jadwal', 'Tidak ada agenda hari ini'),
  _DashboardItem(Icons.chat_bubble_outline, 'Pesan', '2 pesan baru masuk'),
  _DashboardItem(Icons.settings_outlined, 'Pengaturan', 'Atur preferensi akun kamu'),
  _DashboardItem(Icons.help_outline, 'Bantuan', 'Pusat bantuan & pertanyaan umum'),
  _DashboardItem(Icons.info_outline, 'Tentang Aplikasi', 'Versi 1.0.0'),
];

void _showComingSoon(BuildContext context, String label) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text('Halaman "$label" belum tersedia.')));
}

/// Halaman utama setelah login: navbar (logo + menu tengah + profil kanan)
/// dan daftar konten yang dirender pakai ListView.builder.
class HomePage extends StatelessWidget {
  final String name;
  final String email;

  const HomePage({super.key, required this.name, required this.email});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.sand,
      body: SafeArea(
        child: Column(
          children: [
            _NavBar(name: name, email: email),
            Expanded(
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 720),
                  child: ListView.builder(
                    padding: const EdgeInsets.all(20),
                    itemCount: _dashboardItems.length,
                    itemBuilder: (context, index) {
                      final item = _dashboardItems[index];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _DashboardTile(
                          item: item,
                          onTap: () => _showComingSoon(context, item.title),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Satu baris kartu di dalam ListView.builder.
class _DashboardTile extends StatelessWidget {
  final _DashboardItem item;
  final VoidCallback onTap;

  const _DashboardTile({required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.line),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: const Color(0xFFE8F0EC),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(item.icon, size: 20, color: AppColors.forest),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.title,
                      style: const TextStyle(
                        fontSize: 14.5,
                        fontWeight: FontWeight.w600,
                        color: AppColors.ink,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      item.subtitle,
                      style: const TextStyle(fontSize: 12.5, color: AppColors.muted),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, size: 20, color: AppColors.muted),
            ],
          ),
        ),
      ),
    );
  }
}

/// Navbar di paling atas halaman.
class _NavBar extends StatelessWidget {
  final String name;
  final String email;

  const _NavBar({required this.name, required this.email});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 64,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: AppColors.line)),
      ),
      child: Row(
        children: [
          // Logo, kiri
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 30,
                height: 30,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.forest,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.bolt_rounded, size: 18, color: Colors.white),
              ),
              const SizedBox(width: 10),
              const Text(
                'Nimbus',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppColors.ink,
                ),
              ),
            ],
          ),

          // Menu navigasi, tengah — LayoutBuilder dipakai supaya di layar
          // sempit menu teks disembunyikan dan diganti ikon hamburger.
          Expanded(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final isWide = constraints.maxWidth > 320;
                return Align(
                  alignment: Alignment.center,
                  child: isWide
                      ? Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _NavLink(label: 'Home', active: true, onTap: () {}),
                            _NavLink(
                              label: 'Contact',
                              onTap: () => _showComingSoon(context, 'Contact'),
                            ),
                            _NavLink(
                              label: 'Layanan',
                              onTap: () => _showComingSoon(context, 'Layanan'),
                            ),
                            _NavLink(
                              label: 'Tentang',
                              onTap: () => _showComingSoon(context, 'Tentang'),
                            ),
                          ],
                        )
                      : PopupMenuButton<String>(
                          icon: const Icon(Icons.menu, color: AppColors.ink),
                          onSelected: (label) {
                            if (label != 'Home') _showComingSoon(context, label);
                          },
                          itemBuilder: (context) => const [
                            PopupMenuItem(value: 'Home', child: Text('Home')),
                            PopupMenuItem(value: 'Contact', child: Text('Contact')),
                            PopupMenuItem(value: 'Layanan', child: Text('Layanan')),
                            PopupMenuItem(value: 'Tentang', child: Text('Tentang')),
                          ],
                        ),
                );
              },
            ),
          ),

          // Profil, kanan
          _ProfileMenu(name: name, email: email),
        ],
      ),
    );
  }
}

class _NavLink extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _NavLink({required this.label, this.active = false, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: TextButton(
        onPressed: onTap,
        style: TextButton.styleFrom(
          foregroundColor: active ? AppColors.forest : AppColors.muted,
          textStyle: TextStyle(
            fontSize: 14,
            fontWeight: active ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
        child: Text(label),
      ),
    );
  }
}

/// Ikon profil di kanan navbar — diklik memunculkan dropdown Profil & Logout.
class _ProfileMenu extends StatelessWidget {
  final String name;
  final String email;

  const _ProfileMenu({required this.name, required this.email});

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      tooltip: 'Akun',
      offset: const Offset(0, 46),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      onSelected: (value) {
        if (value == 'logout') {
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const LoginPage()),
            (route) => false,
          );
        } else if (value == 'profile') {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => ProfilePage(name: name, email: email)),
          );
        }
      },
      itemBuilder: (context) => [
        PopupMenuItem<String>(
          enabled: false,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                name,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: AppColors.ink),
              ),
              const SizedBox(height: 2),
              Text(email, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
            ],
          ),
        ),
        const PopupMenuDivider(),
        const PopupMenuItem<String>(
          value: 'profile',
          child: Row(
            children: [
              Icon(Icons.person_outline, size: 18, color: AppColors.muted),
              SizedBox(width: 10),
              Text('Profil'),
            ],
          ),
        ),
        const PopupMenuItem<String>(
          value: 'logout',
          child: Row(
            children: [
              Icon(Icons.logout, size: 18, color: AppColors.danger),
              SizedBox(width: 10),
              Text('Logout', style: TextStyle(color: AppColors.danger)),
            ],
          ),
        ),
      ],
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: const [
            CircleAvatar(
              radius: 17,
              backgroundColor: Color(0xFFE8F0EC),
              child: Icon(Icons.person, size: 19, color: AppColors.forest),
            ),
            SizedBox(width: 4),
            Icon(Icons.keyboard_arrow_down_rounded, size: 18, color: AppColors.muted),
          ],
        ),
      ),
    );
  }
}