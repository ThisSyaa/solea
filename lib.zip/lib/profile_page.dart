import 'package:flutter/material.dart';
import 'app_theme.dart';

/// Halaman profil — dibuka dari dropdown ikon profil di navbar Home.
class ProfilePage extends StatelessWidget {
  final String name;
  final String email;

  const ProfilePage({super.key, required this.name, required this.email});

  // Ganti isi ini kalau mau pakai foto sungguhan:
  // - Foto dari internet: isi link .jpg/.png (bukan .svg) di sini.
  // - Foto dari file sendiri: lihat catatan cara pakai assets di README/chat.
  static const String urlFoto = '';

  @override
  Widget build(BuildContext context) {
    final punyaFoto = urlFoto.isNotEmpty;

    return Scaffold(
      backgroundColor: AppColors.sand,
      appBar: AppBar(
        backgroundColor: AppColors.sand,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          'Profil',
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: AppColors.ink),
        ),
        iconTheme: const IconThemeData(color: AppColors.ink),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.line, width: 1.5),
                ),
                child: CircleAvatar(
                  radius: 62,
                  backgroundColor: const Color(0xFFE8E4DA),
                  backgroundImage: punyaFoto ? NetworkImage(urlFoto) : null,
                  child: punyaFoto
                      ? null
                      : const Icon(Icons.person_rounded, size: 62, color: AppColors.forest),
                ),
              ),
              const SizedBox(height: 26),
              Text(
                name,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.4,
                  color: AppColors.ink,
                ),
              ),
              const SizedBox(height: 7),
              Text(
                email,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 14, color: AppColors.muted),
              ),
            ],
          ),
        ),
      ),
    );
  }
}